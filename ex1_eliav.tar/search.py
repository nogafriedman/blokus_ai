"""
In search.py, you will implement generic search algorithms
"""

import util


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        util.raiseNotDefined()

    def is_goal_state(self, state):
        """
        state: Search state

        Returns True if and only if the state is a valid goal state
        """
        util.raiseNotDefined()

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        util.raiseNotDefined()

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        util.raiseNotDefined()



def depth_first_search(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches
    the goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    """
    stack = util.Stack()
    visited = set()
    stack.push((problem.get_start_state(), [], 0))  # (state, path, cost)

    while not stack.isEmpty():
        state, path, cost = stack.pop()
        if problem.is_goal_state(state):
            return path  # Return the path to the goal state

        if state not in visited:
            visited.add(state)
            for successor, action, step_cost in problem.get_successors(state):
                new_path = path + [action]
                new_cost = cost + step_cost
                stack.push((successor, new_path, new_cost))

    return []

def breadth_first_search(problem):
    """
    Search the shallowest nodes in the search tree first.
    """
    queue = util.Queue()  # Use Queue for FIFO behavior
    visited = set()  # To keep track of visited nodes
    queue.push((problem.get_start_state(), [], 0))  # (state, path, cost)

    while not queue.isEmpty():
        state, path, cost = queue.pop()

        # Check if the current state is a goal state
        if problem.is_goal_state(state):
            return path  # Return the path to the goal state

        # Ensure each state is visited only once
        if state in visited:
            continue

        visited.add(state)
        # Explore each successor of the current state
        for successor_state, action, step_cost in problem.get_successors(state):
            if successor_state not in visited:
                new_path = path + [action]  # Append the new action to the path
                new_cost = cost + step_cost  # Accumulate the cost
                queue.push((successor_state, new_path, new_cost))

    return []  # Return an empty list if no path to goal is found


def uniform_cost_search(problem):
    """
    Search the node of least total cost first.
    """
    "*** YOUR CODE HERE ***"
    return a_star_search(problem, null_heuristic)


def null_heuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0



class Node:
    def __init__(self, state, actions, cost):
        self.state = state
        self.actions = actions
        self.cost = cost

    def __lt__(self, other: 'Node') -> bool:
        return True

    def __iter__(self):
        return iter((self.state, self.actions, self.cost))

def a_star_search(problem, heuristic=null_heuristic):
    """
    Search the node that has the lowest combined cost and heuristic first.
    """
    pq = util.PriorityQueue()  # Initialize the priority queue
    start_state = problem.get_start_state()
    item = Node(start_state, [], 0)
    pq.push(item, 0)  # Each entry is ((state, path to state, path cost), priority)
    visited = {}  # Dictionary to track the lowest cost to a visited state

    while not pq.isEmpty():
        current_state, path, cost = pq.pop()

        if problem.is_goal_state(current_state):
            return path  # Successfully found the goal

        if current_state in visited and not cost < visited[current_state]: continue
        # if current_state not in visited or cost < visited[current_state]:
        visited[current_state] = cost  # Record or update the lowest cost to the current state

        for successor, action, step_cost in problem.get_successors(current_state):
            new_cost = cost + step_cost
            if successor not in visited or new_cost < visited[successor]:
                new_path = path + [action]
                priority = new_cost + heuristic(successor, problem)
                item = Node(successor, new_path, new_cost)
                pq.push(item, priority)

    return []  # If no path is found, return an empty list




# Abbreviations
bfs = breadth_first_search
dfs = depth_first_search
astar = a_star_search
ucs = uniform_cost_search