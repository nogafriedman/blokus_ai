from board import Board
from search import SearchProblem, ucs
import util

EMPTY = -1


class BlokusFillProblem(SearchProblem):
    """
    A one-player Blokus game as a search problem.
    This problem is implemented for you. You should NOT change it!
    """

    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0)):
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.expanded = 0

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        """
        state: Search state
        Returns True if and only if the state is a valid goal state
        """
        return not any(state.pieces[0])

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, 1) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        return len(actions)


#####################################################
# This portion is incomplete.  Time to write code!  #
#####################################################
class BlokusCornersProblem(SearchProblem):
    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0)):
        self.expanded = 0
        self.starting_point = starting_point
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.targets = [(0, 0), (0, board_w - 1), (board_h - 1, 0), (board_h - 1, board_w - 1)]

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        return all(state.get_position(x, y) != EMPTY for y, x in self.targets)

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, move.piece.get_num_tiles()) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        "*** YOUR CODE HERE ***"
        return sum(action.piece.get_num_tiles() for action in actions)





def blokus_corners_heuristic(state, problem):
    """
    Your heuristic for the BlokusCornersProblem goes here.

    This heuristic must be consistent to ensure correctness.  First, try to come up
    with an admissible heuristic; almost all admissible heuristics will be consistent
    as well.

    If using A* ever finds a solution that is worse uniform cost search finds,
    your heuristic is *not* consistent, and probably not admissible!  On the other hand,
    inadmissible or inconsistent heuristics may find optimal solutions, so be careful.
    """
    "*** YOUR CODE HERE ***"
    targets = problem.targets
    # Get all tiles on the board
    filled_positions = [(x, y) for x in range(state.board_w) for y in range(state.board_h) if
                        state.get_position(x, y) != EMPTY]

    # Identify all uncovered targets
    uncovered_targets = [target for target in targets if state.get_position(target[1], target[0]) == EMPTY]

    if not uncovered_targets:
        return 0  # All targets are covered

    if not filled_positions:
        filled_positions = [problem.starting_point]

    # Find the closest uncovered target
    closest_dists_to_targets = [min(chebyshev_distance(cur, uncovered_target[::-1]) for cur in filled_positions) for
                                uncovered_target in
                                uncovered_targets]


    return max(closest_dists_to_targets)+ len(uncovered_targets) - 1



class BlokusCoverProblem(SearchProblem):
    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0), targets=[(0, 0)]):
        self.targets = targets.copy()
        self.expanded = 0
        self.starting_point = starting_point
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        "*** YOUR CODE HERE ***"

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        "*** YOUR CODE HERE ***"
        return all(state.get_position(x, y) != EMPTY for y, x in self.targets)

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, move.piece.get_num_tiles()) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        "*** YOUR CODE HERE ***"
        return sum(action.piece.get_num_tiles() for action in actions)



def blokus_cover_heuristic(state, problem: BlokusCoverProblem):
    """
    A heuristic that uses the minimum spanning tree of the distances between the uncovered
    target points plus the Chebyshev distance to the closest uncovered target.
    """
    targets = problem.targets
    # Get all tiles on the board
    filled_positions = [(x, y) for x in range(state.board_w) for y in range(state.board_h) if
                        state.get_position(x, y) != EMPTY]

    # Identify all uncovered targets
    uncovered_targets = [target for target in targets if state.get_position(target[1], target[0]) == EMPTY]

    if not uncovered_targets:
        return 0  # All targets are covered

    if not filled_positions:
        filled_positions = [problem.starting_point]

    # Find the closest uncovered target
    closest_dists_to_targets = [min(chebyshev_distance(cur, uncovered_target[::-1]) for cur in filled_positions) for
                                uncovered_target in
                                uncovered_targets]

    return max(max(closest_dists_to_targets), len(uncovered_targets))



def chebyshev_distance(p1, p2):
    """
    Calculate the Chebyshev distance between two points p1 and p2.
    """
    return max(abs(p1[0] - p2[0]), abs(p1[1] - p2[1]))
